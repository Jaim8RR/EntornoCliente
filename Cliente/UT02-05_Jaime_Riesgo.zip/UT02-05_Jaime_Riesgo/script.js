// JavaScript externo: ejecuta una alerta en este documento HTML
function showInlineAlert2() {
    alert("Este es un ejemplo de integracion Externa.");
}


